package jvm.classStruct;

/**
 * 类结构
 * @author: wyj
 * @date: 2020/06/18
 */
public class Hello {
    public static void main(String[] args) {
        System.out.println("hello hello");
        //javac -parameters -d . Hello.java 编译java文件
        //javap -v Hello.class 将class字节码文件进行翻译
    }
}
