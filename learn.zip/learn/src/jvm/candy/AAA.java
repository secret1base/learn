package jvm.candy;

/**
 * @author: wyj
 * @date: 2020/07/02
 */
public class AAA {
     static final int i=0;

}
