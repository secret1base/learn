package jvm.candy;

/**
 * 默认构造器
 * @author: wyj
 * @date: 2020/06/30
 */
public class DefaultConstruct {
}
