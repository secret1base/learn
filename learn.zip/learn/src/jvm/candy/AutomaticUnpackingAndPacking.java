package jvm.candy;

/**
 * 自动拆装箱
 * @author: wyj
 * @date: 2020/06/30
 */
public class AutomaticUnpackingAndPacking {
    public static void main(String[] args) {
        Integer x=10;
        int i=x;
    }
}
