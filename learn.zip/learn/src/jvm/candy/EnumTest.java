package jvm.candy;

public enum EnumTest {
    ONE,TWO,THREE
}
