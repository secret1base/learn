package jvm.candy;

/**
 * @author: wyj
 * @date: 2020/07/01
 */
public class TestClassInit {
    public static final Integer i=1;
//    public static final int i=1;
//    public static int i=1;
}
