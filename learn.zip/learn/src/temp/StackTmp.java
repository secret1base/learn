//package temp;
//
///**
// * @author: wyj
// * @date: 2020/07/15
// */
//public class StackTmp<T> {
////    5、栈：压栈、弹栈、判空、获取长度、遍历
//    public class Node{
//        T item;
//        Node next;
//        public Node
//    }
//}
